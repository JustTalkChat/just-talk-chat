import { DynamoDB } from 'aws-sdk';

const docClient = new DynamoDB.DocumentClient({ region: 'us-west-2' });

// Define the DynamoDB table name
const tableName = 'Messages';

export const handler = async (event) => {
  try {
    // Parse the query parameters to get sender and recipient IDs
    const queryParams = event.queryStringParameters || {};

    // Ensure sender and recipient IDs are provided
    if (!queryParams.sender || !queryParams.recipient) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Sender and recipient IDs are required' }),
      };
    }

    // Create a query to retrieve messages for a specific sender and recipient
    const query = {
      TableName: tableName,
      KeyConditionExpression: 'sender = :sender AND recipient = :recipient',
      ExpressionAttributeValues: {
        ':sender': queryParams.sender,
        ':recipient': queryParams.recipient,
      },
    };

    // Query DynamoDB for messages
    const result = await docClient.query(query).promise();

    // Return the retrieved messages
    return {
      statusCode: 200,
      body: JSON.stringify({ messages: result.Items }),
    };
  } catch (error) {
    console.error('Error retrieving messages:', error);
    // Return an error response
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error retrieving messages' }),
    };
  }
};
