const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    const userId = parseInt(event.pathParameters.id, 10);

    if (!userId) {
        return {
            statusCode: 400,
            body: JSON.stringify({ error: 'UserID is required' }),
        };
    }

    const params = {
        TableName: 'Users',
        Key: {
            UserID: userId
        }
    };

    try {
        await dynamoDB.delete(params).promise();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'User deleted successfully' }),
        };
    } catch (error) {
        console.error('Error deleting user:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Could not delete user' }),
        };
    }
};
